export class CustomerId
{
    customerId:number;
}