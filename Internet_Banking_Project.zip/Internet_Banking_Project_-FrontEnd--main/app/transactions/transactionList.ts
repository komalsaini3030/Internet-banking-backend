import {TransactionDetail} from './transactionsDetails'
export class transactions
{
    transactions:TransactionDetail[];
}