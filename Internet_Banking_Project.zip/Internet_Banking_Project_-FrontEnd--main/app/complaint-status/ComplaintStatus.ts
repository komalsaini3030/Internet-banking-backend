export class ComplaintStatus{
    complaintNo:number;
    status:string;
}