export class ComplaintNo{
    complaintNo:number
}