export class ResetCheck{
    customerId:number;
}