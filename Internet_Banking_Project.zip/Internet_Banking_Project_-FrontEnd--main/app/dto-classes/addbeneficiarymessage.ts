export class Addbeneficiarymessage
{
    message:string;
}