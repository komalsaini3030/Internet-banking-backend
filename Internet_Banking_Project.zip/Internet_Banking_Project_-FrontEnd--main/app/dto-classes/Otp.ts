export class Otp{
    otp:string;
}