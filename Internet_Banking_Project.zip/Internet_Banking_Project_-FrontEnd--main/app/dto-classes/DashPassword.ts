export class DashPassword{
    customerId:number= Number(sessionStorage.getItem("customerId"));
    loginPassword:string;
    transPassword:string;
}