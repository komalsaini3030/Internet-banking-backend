export class Status{
    status:string;
}