export class GetBeneficiary
{
    beneficiaryNickName:string;
    beneficiaryName:string;
    beneficiaryAccountNo:number;
}