export class ResetPass{
    password:string;
}