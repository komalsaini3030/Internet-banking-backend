export class TransactionOtp
{
    customerId:number = Number(sessionStorage.getItem("customerId"));
}