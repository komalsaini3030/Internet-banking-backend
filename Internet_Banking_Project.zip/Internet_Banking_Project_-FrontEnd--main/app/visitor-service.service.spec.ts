import { TestBed } from '@angular/core/testing';

import { VisitorServiceService } from './visitor-service.service';

describe('VisitorServiceService', () => {
  let service: VisitorServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VisitorServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
