export class Admin
{
    adminId:number;
    adminPassword:string;
}