export class AdminLoginStatus{
    status:string;
    message:string;
    adminId:number;
    adminName:string;
}