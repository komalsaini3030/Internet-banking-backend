export class Complaint
{

    accountType:string;
    accountNumber:number;
    nameComplaint:string;
    branchCode:string;
    mobileNumber:number;
    email:string;
    categoryOfComplaint:string;
    complaintDesc:String;
    captcha:string;
}