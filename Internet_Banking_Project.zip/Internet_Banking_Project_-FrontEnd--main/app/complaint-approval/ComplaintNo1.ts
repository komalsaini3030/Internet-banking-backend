export class ComplaintNo1{
    complaintNo:number
}