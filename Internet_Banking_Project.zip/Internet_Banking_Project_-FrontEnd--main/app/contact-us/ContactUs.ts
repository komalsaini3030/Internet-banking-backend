export class Contact
{
    firstName:string;
    lastName:string;
    place:string;
    subject:string;
    email:string;
    status:string ="not-contacted";
}