export class Employee{
    name:string;

    Employee(name){
      name=this.name;
    }
  }