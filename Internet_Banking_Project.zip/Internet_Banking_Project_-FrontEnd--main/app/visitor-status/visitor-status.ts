export class VisitorStatus{
    serialRefNo:number;
    status:string;
  }