import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pre-login',
  templateUrl: './pre-login.component.html',
  styleUrls: ['./pre-login.component.css','./normalize.css']
})
export class PreLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
