export class accountStatement
{
    accountNo:number = Number(sessionStorage.getItem("accountNo"));
    fromDate:Date;
    toDate:Date;
}