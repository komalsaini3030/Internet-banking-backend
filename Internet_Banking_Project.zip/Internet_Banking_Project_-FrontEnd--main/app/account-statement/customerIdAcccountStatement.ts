export class CustomerId
{
    customerId:number = Number(sessionStorage.getItem("customerId"));
}