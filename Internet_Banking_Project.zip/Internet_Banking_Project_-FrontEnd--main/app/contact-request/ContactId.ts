export class ContactId{
    contactId:number
}