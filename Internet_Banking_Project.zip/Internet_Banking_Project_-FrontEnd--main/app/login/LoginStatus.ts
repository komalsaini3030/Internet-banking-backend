export class LoginStatus{
    status:string;
    message:string;
    customerId:number;
    customerFirstName:string;
}