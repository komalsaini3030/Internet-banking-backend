export class Login {
    customerId: number;
    loginPassword: string;
}