export class ReferenceNo
{
    serviceRefNo:number;
}