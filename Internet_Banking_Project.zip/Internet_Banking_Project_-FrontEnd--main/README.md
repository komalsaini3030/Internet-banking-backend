# Internet_Banking_Project_(FrontEnd)
 FrondEnd component of the Iternet Banking project developed in Angular JS, HTML, CSS, Typescript.
 
 UI/UX Overview  Main Landing page:-
 ![image](https://user-images.githubusercontent.com/49650347/182791049-775f7096-7dba-4441-809a-da074007659c.png)
![image](https://user-images.githubusercontent.com/49650347/182791477-c593f616-4afe-4478-93f8-d010ca8ebca7.png)
![image](https://user-images.githubusercontent.com/49650347/182791641-f9f47d74-b622-42fc-a4a0-3c4292b5d915.png)
![image](https://user-images.githubusercontent.com/49650347/182791733-dc60501e-20e3-4fac-b248-fa8227b18ac4.png)
![image](https://user-images.githubusercontent.com/49650347/182792168-33acadd8-14ec-47b0-ad6d-b73d9bdadf18.png)

Login Page(Customer):-
![image](https://user-images.githubusercontent.com/49650347/182792496-f706c4d4-4ea2-4d9d-b5f0-9147d7a66016.png)

Login Page (Admin):-
![image](https://user-images.githubusercontent.com/49650347/182792641-068540e8-98f6-448b-bbb1-4e64c9d80c9b.png)

Account Opening Page (Accountype):-
![image](https://user-images.githubusercontent.com/49650347/182792790-a152beee-d081-49bf-8e65-7efbbf30797e.png)
![image](https://user-images.githubusercontent.com/49650347/182792911-dda8843a-41cf-4760-b31e-28a2dcdad217.png)

Complaint Page:-
![image](https://user-images.githubusercontent.com/49650347/182793091-7784da92-e38d-4226-83c8-82dfa0daa632.png)

Contact Us:-
![image](https://user-images.githubusercontent.com/49650347/182793220-7090a989-c067-428d-9707-120543b4a0b4.png)

Forget Password Page:- Dual Authentication is used (Email based and Mobile OTP Based) - Email Sample Attached Below.
![image](https://user-images.githubusercontent.com/49650347/182793464-b81745ca-41f6-44a1-a766-94f928a64929.png)

Account Locked Page (On incorrect login credentials input 3 times, the account will get locked and need to do password reset):-
![image](https://user-images.githubusercontent.com/49650347/182793909-d2cada26-df1b-4e73-8eb8-72e6d73e1bfe.png)

Sample Mails (SMTP):-
![image](https://user-images.githubusercontent.com/49650347/182794390-d451d530-d9b6-49cb-84f5-850319c7bc5e.png)

![image](https://user-images.githubusercontent.com/49650347/182794533-02aa2cee-1b7b-47d8-97ee-226af54c4615.png)

![image](https://user-images.githubusercontent.com/49650347/182794696-f6e7b054-3d4b-4af6-af49-493a57542aed.png)




 
