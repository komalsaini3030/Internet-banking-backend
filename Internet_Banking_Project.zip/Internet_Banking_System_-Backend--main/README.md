# Internet_Banking_System_(Backend)
 Backend codes or banking portal developed in Java Springboot Framework
 
 Below is the project Stucture :-
 
 ![image](https://user-images.githubusercontent.com/49650347/182787809-66e8e1b4-87d1-4450-8dbc-61cecee521fb.png)

