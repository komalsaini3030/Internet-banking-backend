package com.isb.dto;

public class ReferenceNo {

	long serviceRefNo;
	
	

	public ReferenceNo(long serviceRefNo) {
		super();
	this.serviceRefNo = serviceRefNo;
   }

	public long getServiceRefNo() {
		return serviceRefNo;
	}

	public void setServiceRefNo(long serviceRefNo) {
		this.serviceRefNo = serviceRefNo;
	}
	
}
