package com.isb.dto;

public class ContactId {
	long  contactId;

	public ContactId(long contactId) {
		super();
		this.contactId = contactId;
	}

	public long getContactId() {
		return contactId;
	}

	public void setContactId(long contactId) {
		this.contactId = contactId;
	}
	
	
}
