package com.isb.dto;

public class ServiceReference {
	
long serviceRefNo;
	
	

//	public ServiceReference(long serviceRefNo) {
//	super();
//		this.serviceRefNo = serviceRefNo;
//   }

	public long getServiceRefNo() {
		return serviceRefNo;
	}

	public void setServiceRefNo(long serviceRefNo) {
		this.serviceRefNo = serviceRefNo;
	}

}
