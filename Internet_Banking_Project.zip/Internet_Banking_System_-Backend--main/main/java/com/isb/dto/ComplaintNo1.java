package com.isb.dto;

public class ComplaintNo1 {

	private long  complaintNo;
	
	
	public ComplaintNo1(long complaintNo) {
		super();
		this.complaintNo = complaintNo;
	}

	public long getComplaintNo() {
		return complaintNo;
	}

	public void setComplaintNo(long complaintNo) {
		this.complaintNo = complaintNo;
	}
	
}
