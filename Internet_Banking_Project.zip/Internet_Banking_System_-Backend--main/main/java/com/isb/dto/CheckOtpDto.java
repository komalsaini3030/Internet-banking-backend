package com.isb.dto;

///check otp name change

public class CheckOtpDto {
	String otp;
	
	
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	
	
}
