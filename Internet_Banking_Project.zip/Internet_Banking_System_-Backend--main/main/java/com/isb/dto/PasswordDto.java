package com.isb.dto;

public class PasswordDto {

	//private long customerId;
	private String password;

	
	//public long getCustomerId() {
	//	return customerId;
	//}

	//public void setCustomerId(long customerId) {
	//	this.customerId = customerId;
	//}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
