package com.isb.dto;

import java.math.BigDecimal;

public class CustomerIdBDto {
	private BigDecimal customerId;

	public BigDecimal getCustomerId() {
		return customerId;
	}

	public void setCustomerId(BigDecimal customerId) {
		this.customerId = customerId;
	}
}
