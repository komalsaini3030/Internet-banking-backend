package com.isb.dto;

public class VisitorStatus {

	long serviceRefNo;
	String status;

	public long getServiceRefNo() {
		return serviceRefNo;
	}

	public void setServiceRefNo(long serviceRefNo) {
		this.serviceRefNo = serviceRefNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
