package com.isb.dto;

public class IdCheckDto {

	private long customerId;
	//private int otp;
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
//	public int getOtp() {
//		return otp;
//	}
//	public void setOtp(int otp) {
//		this.otp = otp;
//	}
	
	
}
