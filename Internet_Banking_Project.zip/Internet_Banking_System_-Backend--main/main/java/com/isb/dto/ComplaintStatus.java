package com.isb.dto;

public class ComplaintStatus {
	
	long  complaintNo;
	String status;
	
	public long getComplaintNo() {
		return complaintNo;
	}
	public void setComplaintNo(long complaintNo) {
		this.complaintNo = complaintNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
}
