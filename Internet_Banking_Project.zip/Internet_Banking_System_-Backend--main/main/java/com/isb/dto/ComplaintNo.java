package com.isb.dto;

public class ComplaintNo {
 long  complaintNo;




public long getComplaintNo() {
	return complaintNo;
}

public void setComplaintNo(long complaintNo) {
	this.complaintNo = complaintNo;
}
 
 
}
