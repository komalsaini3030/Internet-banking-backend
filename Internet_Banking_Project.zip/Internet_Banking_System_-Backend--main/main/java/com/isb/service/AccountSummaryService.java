package com.isb.service;

import com.isb.entity.Account;

public interface AccountSummaryService {
	public Account accountSummary(long customerId);
}
