package com.isb.service;

import com.isb.entity.Customer;

public interface UserProfileService {
	Customer UserProfileService(long customerId);
}
